
from parameters import *

def compute_signal_ylims(clustering_info, signal_tag):
	return ylims