
from hcluster import medians



    #if args.signal_wide_cluster:
        #profiles_by_signal = partition_by_identifier(profiles_info_list, lambda x: x.signal_tag)
        #shape_data = np.array()
        #for signal_pil in profiles_by_signal:
            #for profiles_info in signal_pil:
                #clustering_info = make_clustering_info(profiles_info)
                #clustering_info.make_PD()
                #for unflipped_cluster in clustering_info.unflipped_clusters:
                    #data_rows.append(average(clustering_info.data.get_rows(unflipped_cluster)))





